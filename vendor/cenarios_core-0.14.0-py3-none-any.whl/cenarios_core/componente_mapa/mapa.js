/* Componente de mapa — o deck.gl vivo entre um rerun e outro.
 *
 * O `st.pydeck_chart` recria o canvas do deck a cada rerun, e por isso nem
 * `FlyToInterpolator` nem fade tinham de onde partir (ver `docs/mapa-clique.md`,
 * "Transição"). Aqui a instância do Deck nasce uma vez, no primeiro
 * `streamlit:render`, e os renders seguintes só chamam `setProps`: as camadas
 * novas entram com a cor interpolando (`transitions` na camada, definido em
 * `src/mapa.py`) e a câmera voa do quadro antigo para o novo.
 *
 * Fala com o Streamlit pelo protocolo de componente (v1), sem a lib npm: três
 * mensagens — `componentReady`, `setFrameHeight`, `setComponentValue` — e a
 * escuta de `streamlit:render`. O spec que chega é o JSON do pydeck, convertido
 * pelo `JSONConverter` do próprio deck.gl, que é o que o widget do pydeck faz.
 */
(function () {
  "use strict";

  const raiz = document.getElementById("mapa");
  const converter = new deck.JSONConverter({
    configuration: new deck.JSONConfiguration({ classes: Object.assign({}, deck) }),
  });

  let instancia = null;
  let quadroAtual = null;     // "lat,lon,zoom" do último enquadramento pedido
  let vistaAtual = null;      // viewState corrente, para os botões de zoom
  let tooltipSpec = null;
  let contador = 0;
  // Prefixo por carga do iframe: se ele recarregar no meio da sessão, o nonce
  // não repete o que o Python já viu.
  const prefixo = Date.now().toString(36);

  function enviar(tipo, dados) {
    window.parent.postMessage(Object.assign({ isStreamlitMessage: true, type: tipo }, dados), "*");
  }

  // --- tooltip: o template `{campo}` do pydeck, resolvido pelas properties --
  function tooltip(info) {
    if (!info.object || !tooltipSpec) return null;
    const props = info.object.properties || {};
    const html = tooltipSpec.html.replace(/\{([^}]+)\}/g, (_, k) => {
      const v = props[k] !== undefined ? props[k] : info.object[k];
      return v === undefined || v === null ? "" : String(v);
    });
    return { html, style: tooltipSpec.style || {} };
  }

  function aoClicar(info) {
    if (!info.object) return;
    contador += 1;
    ultimoClique = { nonce: prefixo + "-" + contador, properties: info.object.properties || {} };
    enviar("streamlit:setComponentValue", { value: ultimoClique, dataType: "json" });
  }

  // --- envio incremental: a malha fica aqui, e não volta a cada rerun -----
  //
  // A camada GeoJSON grande chega em colunas (`mapa_componente.py`, topo do
  // módulo): cada coluna — geometria, cor, nome — em pedaços chamados pelo
  // hash do conteúdo. Pedaço que já veio chega só como `{h}`; o que é novo
  // traz `v`. Os pedaços ficam em `guardados` e a FeatureCollection é
  // remontada aqui, antes do conversor do deck.gl, igual à de antes.
  const MARCA = "@@cenarios_colunas";
  const TETO_GUARDADO = 48e6; // caracteres de JSON, aproximado
  const guardados = new Map(); // hash -> {valores, tam}, do menos ao mais usado
  let tamanhoGuardado = 0;
  let ultimoClique = { nonce: null, properties: null };
  let pedidos = 0;
  let pedidosSeguidos = 0;

  function guardar(p) {
    if (!("v" in p) || guardados.has(p.h)) return;
    const v = p.v;
    const valores = Array.isArray(v) ? v : v.i.map((i) => v.u[i]);
    const tam = p.t || valores.length;
    guardados.set(p.h, { valores, tam });
    tamanhoGuardado += tam;
  }

  function usar(h) {
    const e = guardados.get(h);
    guardados.delete(h);
    guardados.set(h, e);
    return e.valores;
  }

  // Devolve os hashes que faltam (e então não mexe no spec), ou [] com as
  // camadas remontadas.
  function remontar(spec) {
    const dados = (spec.layers || []).map((c) => c && c.data).filter((d) => d && d[MARCA]);
    if (!dados.length) return [];
    const pedacos = [];
    dados.forEach((d) => {
      Object.values(d.feicao).concat(Object.values(d.propriedades)).forEach((col) => {
        col.forEach((p) => pedacos.push(p));
      });
    });
    // Guarda tudo antes de conferir: pedaço repetido no mesmo spec (`rotulo`
    // igual ao nome) só traz o conteúdo na primeira vez.
    pedacos.forEach(guardar);
    const faltam = pedacos.filter((p) => !guardados.has(p.h)).map((p) => p.h);
    if (faltam.length) return faltam;

    (spec.layers || []).forEach((camada) => {
      const d = camada && camada.data;
      if (!d || !d[MARCA]) return;
      const juntar = (grupo) => Object.keys(grupo).map((k) => [k, [].concat(...grupo[k].map((p) => usar(p.h)))]);
      const feicao = juntar(d.feicao);
      const props = juntar(d.propriedades);
      const features = new Array(d.n);
      for (let i = 0; i < d.n; i++) {
        const f = {};
        for (const [k, col] of feicao) f[k] = col[i];
        const pr = {};
        for (const [k, col] of props) pr[k] = col[i];
        f.properties = pr;
        features[i] = f;
      }
      camada.data = Object.assign({}, d.colecao, { features });
    });

    // Poda o menos usado, nunca o que está na tela.
    const emUso = new Set(pedacos.map((p) => p.h));
    for (const [h, e] of guardados) {
      if (tamanhoGuardado <= TETO_GUARDADO) break;
      if (emUso.has(h)) continue;
      guardados.delete(h);
      tamanhoGuardado -= e.tam;
    }
    return [];
  }

  function devolverFoco() {
    // No próximo tick, para não atropelar o clique que o deck ainda está
    // processando (`onClick` vem depois do `pointerup`).
    setTimeout(() => {
      if (document.activeElement && document.activeElement !== document.body) {
        document.activeElement.blur();
      }
      try { window.parent.focus(); } catch (e) { /* origem diferente: ignora */ }
    }, 0);
  }

  function zoom(delta) {
    if (!instancia || !vistaAtual) return;
    instancia.setProps({
      initialViewState: Object.assign({}, vistaAtual, {
        zoom: Math.max(2, Math.min(12, vistaAtual.zoom + delta)),
        transitionDuration: 300,
        transitionEasing: (t) => 1 - Math.pow(1 - t, 3),
      }),
    });
  }
  document.getElementById("mais").addEventListener("click", () => { zoom(1); devolverFoco(); });
  document.getElementById("menos").addEventListener("click", () => { zoom(-1); devolverFoco(); });

  // A altura pedida pelo Python é de tela de trabalho; o Python não sabe a
  // largura do aparelho, mas este iframe sabe a sua.
  //
  // Pernambuco é largo: numa caixa estreita e alta, quem limita o desenho é a
  // largura, e o resto da altura vira vazio. Num aparelho de 375px a caixa
  // tinha 318 por 640 e o estado ocupava uma faixa no meio, com cerca de
  // 500px de nada em volta. O teto de 1,15 vez a largura tira o vazio sem
  // encolher o mapa.
  //
  // Só limita, nunca aumenta: em tela de trabalho a altura do Python continua
  // valendo, porque lá ela está casada com a coluna da direita.
  //
  // O teto é **do painel** (`desenhar(..., proporcao_maxima=)`), porque
  // depende da forma do território: 1,15 serve a Pernambuco e ao DF, que são
  // largos. O Recife é alto — num território alto a caixa alta é a certa, em
  // qualquer tela —, e com 1,15 fixo o mapa de 720px saía com 642 até no
  // computador. `null` desliga o teto.
  function alturaUtil(pedida, proporcao) {
    if (!proporcao) return pedida;
    const largura = raiz.clientWidth || window.innerWidth || pedida;
    return Math.round(Math.min(pedida, Math.max(largura * proporcao, 280)));
  }

  // O zoom do Python foi calculado para uma coluna de `vs.largura` px. Numa
  // janela estreita a coluna real é menor, e o território saía cortado — o
  // Brasil, quase quadrado, perdia o Norte inteiro numa janela de 960 px.
  // Aqui o zoom é refeito com a largura real, pela mesma conta de
  // `mapa.enquadrar` (tile de 512 px, folga de 0,05).
  //
  // Só diminui, nunca aumenta: em caixa mais larga que a suposta o zoom do
  // Python continua valendo — é o comportamento de antes, e a posição do
  // quadro da ilha foi calculada para ele.
  function zoomQueCabe(vs, altura) {
    const ext = vs.extensao;
    const largura = raiz.clientWidth;
    if (!ext || !largura || !vs.largura || largura >= vs.largura) return vs.zoom;
    const escalas = [];
    if (ext[0] > 0) escalas.push(largura / ext[0]);
    if (ext[1] > 0) escalas.push(altura / ext[1]);
    if (!escalas.length) return vs.zoom;
    const cabe = Math.log2(Math.min(...escalas) * 360 / 512) - 0.05;
    return Math.max(2, Math.min(vs.zoom, cabe));
  }

  function render(args) {
    const spec = typeof args.spec === "string" ? JSON.parse(args.spec) : args.spec;
    tooltipSpec = args.tooltip || null;
    // Nome do quadro para leitor de tela. O Streamlit o batiza com o nome
    // interno do componente — "cenarios_core ponto mapa underscore
    // componente" —, que não diz nada. O mapa é um canvas e continua fora do
    // alcance do leitor; o nome serve para reconhecer o quadro e seguir em
    // frente. Vem do painel (`desenhar(..., titulo=)`): o core não sabe se o
    // mapa é de Pernambuco, do Recife ou do DF.
    try {
      const quadro = window.frameElement;
      if (quadro) quadro.title = args.titulo || "Mapa";
    } catch (e) { /* iframe de outra origem: segue sem nome */ }
    const altura = alturaUtil(Number(args.altura) || 500, args.proporcao_maxima);
    // Quem pediu menos movimento no sistema não recebe voo nem interpolação:
    // a câmera vai direto ao enquadramento novo.
    const menosMovimento = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const duracao = menosMovimento ? 0 : (Number(args.transicao) || 0);

    raiz.style.height = altura + "px";
    enviar("streamlit:setFrameHeight", { height: altura });

    // Só as camadas passam pelo conversor: o resto do spec (views, mapStyle,
    // initialViewState) é decidido aqui.
    if (menosMovimento) {
      // A interpolação de cor é declarada no spec (`transitions` da camada,
      // `src/mapa.py`); apagada aqui, no único lugar que sabe da preferência.
      (spec.layers || []).forEach((c) => { if (c.transitions) delete c.transitions; });
    }
    // O iframe recarregou no meio da sessão e o Python mandou só hashes:
    // pede tudo de novo e fica com o desenho que tem. O pedido leva o último
    // clique, para o Python não o tratar como clique novo. Três pedidos sem
    // sucesso e para — se o reenvio não vier, laço de rerun é pior que mapa
    // parado.
    const faltam = remontar(spec);
    if (faltam.length) {
      if (pedidosSeguidos < 3) {
        pedidosSeguidos += 1;
        pedidos += 1;
        enviar("streamlit:setComponentValue", {
          value: Object.assign({}, ultimoClique, { falta: prefixo + "-f" + pedidos }),
          dataType: "json",
        });
      } else {
        console.error("mapa: faltam pedaços da camada e o reenvio não veio", faltam.length);
      }
      return;
    }
    pedidosSeguidos = 0;
    const camadas = converter.convert({ layers: spec.layers || [] }).layers || [];
    const vs = spec.initialViewState || {};
    const alvo = {
      latitude: vs.latitude, longitude: vs.longitude, zoom: zoomQueCabe(vs, altura),
      bearing: 0, pitch: 0,
    };
    const quadro = [alvo.latitude, alvo.longitude, alvo.zoom].join(",");

    if (!instancia) {
      vistaAtual = alvo;
      instancia = new deck.Deck({
        parent: raiz,
        width: "100%",
        height: "100%",
        initialViewState: alvo,
        // Roda do mouse desligada, como no painel de origem: rolar a página
        // sobre o mapa não pode virar zoom. Arrastar continua.
        controller: { scrollZoom: false, doubleClickZoom: false, touchZoom: false, keyboard: false },
        layers: camadas,
        getTooltip: tooltip,
        onClick: aoClicar,
        getCursor: ({ isHovering, isDragging }) => (isDragging ? "grabbing" : isHovering ? "pointer" : "grab"),
        onViewStateChange: ({ viewState }) => { vistaAtual = viewState; },
      });
      quadroAtual = quadro;
      window.__mapa = instancia; // para inspeção no navegador
      // O foco não pode ficar preso no iframe. Depois de clicar ou arrastar
      // o mapa, o canvas ficava com o foco do documento, e o clique seguinte
      // num botão da página só devolvia o foco à página — era preciso clicar
      // duas vezes na métrica. O canvas não precisa de foco (teclado está
      // desligado no controller), então ele sai da ordem de tabulação e o
      // foco volta à página ao soltar o ponteiro.
      const canvas = raiz.querySelector("canvas");
      if (canvas) canvas.tabIndex = -1;
      raiz.addEventListener("pointerup", devolverFoco);
      // O realce de hover (`autoHighlight`) ficava **preso** no último
      // polígono sob o cursor quando o mouse saía do iframe — o deck só o
      // apaga num `pointerleave` do canvas, que na borda do iframe nem sempre
      // chega. Fernando de Noronha, no canto por onde o cursor sai para os
      // controles, era o caso de sempre. Ao sair, o realce é limpo à mão.
      const limparRealce = () => {
        try {
          instancia.layerManager.getLayers().forEach((camada) => {
            if (camada.props.autoHighlight) camada.updateAutoHighlight({ picked: false, color: null });
          });
          instancia.redraw("realce limpo");
        } catch (e) { /* API interna mudou: fica o comportamento antigo */ }
      };
      document.documentElement.addEventListener("pointerleave", limparRealce);
      document.documentElement.addEventListener("mouseleave", limparRealce);
      window.addEventListener("blur", limparRealce);
      return;
    }

    instancia.setProps({ layers: camadas });
    if (quadro === quadroAtual) return;

    // Voo da câmera: só quando o enquadramento pedido mudou. Trocar de
    // métrica não move o mapa, e quem arrastou não é puxado de volta.
    //
    // O voo começa **depois** que a página assentou, não junto com o rerun:
    // o `streamlit:render` chega enquanto o Streamlit ainda redesenha os
    // cards e os gráficos, e nesse pico o laço de animação do deck não ganha
    // frame — medido, o voo de 700 ms saía como um salto. Esperar o navegador
    // ficar ocioso (com teto, para não esperar demais) dá ao voo os frames
    // que ele precisa.
    quadroAtual = quadro;
    vistaAtual = alvo;
    const voo = Object.assign({}, alvo, {
      transitionDuration: duracao,
      transitionInterpolator: new deck.FlyToInterpolator({ speed: 1.4 }),
      transitionEasing: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    });
    const partir = () => {
      if (quadroAtual !== quadro) return; // outro enquadramento chegou antes
      instancia.setProps({ initialViewState: voo });
    };
    if (window.requestIdleCallback) {
      window.requestIdleCallback(partir, { timeout: 350 });
    } else {
      setTimeout(partir, 120);
    }
  }

  window.addEventListener("message", (ev) => {
    const msg = ev.data || {};
    if (msg.type !== "streamlit:render") return;
    try {
      render(msg.args || {});
    } catch (e) {
      console.error("mapa: falha ao renderizar", e);
    }
  });

  enviar("streamlit:componentReady", { apiVersion: 1 });
})();
