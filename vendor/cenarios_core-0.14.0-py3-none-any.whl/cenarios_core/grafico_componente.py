"""Gráficos ECharts como componente próprio — para a transição existir.

O Altair redesenhava do zero a cada rerun: o Vega-Lite não anima entre dois
estados. Este módulo serve `componente_grafico/` (ECharts 5.6 vendorado)
como componente estático: o iframe e a instância do gráfico ficam vivos
entre reruns, e cada render é um `setOption` — o ECharts interpola o que
mudou (barra crescendo, barra trocando de posição, linha se redesenhando).

Cada gráfico é uma função que devolve a **opção** ECharts (um dict), e o
painel a entrega a :func:`desenhar`. As constantes de layout que os painéis
usam para dimensionar os iframes ficam no fim do módulo.

Veio para o cenarios-core em 14/out/2026 a partir do hansepe, o mais
completo dos quatro, com o que só o DFTB (``recado_vazio``, ``casas``) e o
RecifeTB (:func:`recado`, :func:`evolucao_mensal`) tinham. **Correção é
padrão; escolha visual é opção, com o padrão de antes**: ``anos_agrupados``
no canal endêmico, ``rotulos_valor`` na composição e ``area`` na epicurva
são do hansepe e do DFTB, e quem não os passa desenha como sempre desenhou.
Texto que fala do território (o aviso do canal endêmico) fica no painel.

Regras da opção, para a animação funcionar:

- todo item de dado leva ``name``: é por ele que o ECharts casa o item
  antigo com o novo e anima a diferença;
- a série leva ``id`` fixo, pelo mesmo motivo;
- o clique volta como ``{"nonce", "name", "chave"}``, com nonce novo a cada
  clique (mesma regra do mapa — `mapa_componente`).
"""

from __future__ import annotations

import json
import unicodedata
from pathlib import Path

import pandas as pd
import streamlit.components.v1 as components

from . import cores as paleta
from . import formato as ui

#: Fonte e corpo do texto dos gráficos. Iguais nos quatro painéis em
#: 14/out/2026 (`theme/tokens.py`: ``FONTE`` e ``TEXTO_XS``).
FONTE = (
    "system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, "
    "'Apple Color Emoji', 'Segoe UI Emoji', sans-serif"
)
TEXTO_XS = "12px"

DIRETORIO = Path(__file__).resolve().parent / "componente_grafico"

#: Durações da animação, em ms. Mais curtas que o voo do mapa (700): o
#: gráfico é secundário na leitura e não pode terminar depois dele.
ANIMACAO_ENTRADA_MS = 500
ANIMACAO_ATUALIZACAO_MS = 550

#: Tamanho de rótulo de eixo, legenda e tooltip: o degrau `TEXTO_XS` da
#: escala tipográfica do tema, em número — o ECharts quer número, o CSS
#: quer unidade.
_FONTE_PX = int(TEXTO_XS.rstrip("px"))
_COR_EIXO = "rgba(128,128,128,.35)"
_COR_GRADE = "rgba(128,128,128,.18)"

_componente = components.declare_component("grafico_echarts", path=str(DIRETORIO))


def desenhar(option: dict, *, altura: int, key: str):
    """Renderiza a opção ECharts e devolve o último clique (ou ``None``).

    A ``key`` é estável por gráfico — é ela que mantém a instância viva.
    """
    return _componente(
        option=json.dumps(option, ensure_ascii=False, default=_serializar),
        altura=int(altura),
        key=key,
        default=None,
    )


def _serializar(valor):
    """Números do numpy/pandas viram números; o resto, texto."""
    try:
        import numpy as np

        if isinstance(valor, np.generic):
            return valor.item()
    except ImportError:  # pragma: no cover
        pass
    if valor is pd.NA or (isinstance(valor, float) and valor != valor):
        return None
    return str(valor)


def alvo_do_clique(evento, nonce_visto: str | None) -> tuple[str | None, str | None]:
    """``(chave clicada, nonce)`` se o evento é novo; ``(None, None)`` se não."""
    if not isinstance(evento, dict):
        return None, None
    nonce = evento.get("nonce")
    if not nonce or nonce == nonce_visto:
        return None, None
    chave = evento.get("chave")
    if chave in (None, ""):
        chave = evento.get("name")
    return (str(chave) if chave not in (None, "") else None), nonce


def _base() -> dict:
    """O que todo gráfico ECharts daqui compartilha: fonte, animação, eixo."""
    return {
        "animationDuration": ANIMACAO_ENTRADA_MS,
        "animationDurationUpdate": ANIMACAO_ATUALIZACAO_MS,
        "animationEasingUpdate": "cubicOut",
        "textStyle": {"fontFamily": FONTE, "fontSize": _FONTE_PX},
        "tooltip": {
            "trigger": "item",
            "backgroundColor": "rgba(17,24,39,.96)",
            "borderWidth": 0,
            "textStyle": {"color": "#fff", "fontSize": _FONTE_PX},
        },
    }


#: Texto escrito **dentro** de uma barra: claro ou escuro, o que for legível
#: sobre aquela cor. O boletim escreve o N em branco, e em cima do roxo isso
#: dá 7,45:1; em cima do laranja cai para 3,10:1, abaixo do mínimo de 4,5:1
#: da WCAG para 12px.
_CLARO, _ESCURO = "#FFFFFF", "#111827"


def cor_sobre(fundo: str) -> str:
    """A cor de texto mais legível sobre ``fundo``."""
    if paleta.contraste(_CLARO, fundo) >= paleta.contraste(_ESCURO, fundo):
        return _CLARO
    return _ESCURO


def ranking(
    dados: pd.DataFrame,
    *,
    rotulo: str,
    cor: str,
    escala=None,
    selecionado: str | None = None,
    largura_rotulo: int = 150,
    casas: int = 1,
    rotulos_valor: bool = False,
    sufixo: str = "",
    referencia: tuple[str, float] | None = None,
) -> dict:
    """Barras horizontais das maiores geografias, clicáveis — em ECharts.

    ``rotulos_valor`` escreve o valor na ponta de cada barra, como o boletim
    epidemiológico, e então o eixo de números sai: ele só repetiria o que já
    está escrito. ``sufixo`` vai depois do número ("%" nas proporções).
    ``referencia`` (rótulo, valor) traça a linha tracejada de comparação — o
    "Brasil" que o boletim põe entre as UFs. Coluna ``cor`` em ``dados``
    pinta cada barra (a classe de prioridade do município, no tbbrasil) e
    manda sobre a ``escala``. Sem nada disso, o desenho é o de antes.

    ``casas`` é com quantas decimais o tooltip escreve o valor: 1 para taxa,
    0 para contagem (DFTB).

    Mesmas decisões do `graficos.ranking` Altair: horizontal, cor por classe
    do mapa quando há ``escala`` (a barra é da cor do polígono), legenda
    desligada porque a do mapa vale para os dois. O que muda é o que o
    ECharts dá de graça: ao mudar recorte, ano ou métrica, cada barra
    **desliza** para o valor e a posição novos, casada pelo nome.

    ``dados`` tem ``chave``, ``nome`` e ``valor``. A barra ``selecionado``
    (chave) fica opaca e as demais recuam — o destaque do mapa e do ranking
    é o mesmo.
    """
    opt = _base()
    if dados.empty:
        opt.update({
            "title": {
                "text": "Sem dados para ranquear neste recorte",
                "left": "center", "top": "middle",
                "textStyle": {"fontSize": _FONTE_PX, "fontWeight": "normal"},
            },
        })
        return opt

    ordenado = dados.sort_values(["valor", "nome"], ascending=[True, True])
    if escala is not None:
        from . import mapa

        classes = mapa.classificar(ordenado["valor"], escala)
        cores = [escala.cores.get(c, cor) for c in classes]
    else:
        cores = [cor] * len(ordenado)
    if "cor" in ordenado:
        cores = [c if isinstance(c, str) else padrao
                 for c, padrao in zip(ordenado["cor"], cores, strict=True)]

    itens = []
    for (chave, nome, valor), tom in zip(
        ordenado[["chave", "nome", "valor"]].itertuples(index=False), cores, strict=True
    ):
        recuado = selecionado is not None and str(chave) != str(selecionado)
        itens.append({
            "name": str(nome),
            "value": None if pd.isna(valor) else float(valor),
            "chave": str(chave),
            "itemStyle": {"color": tom, "opacity": 0.55 if recuado else 1.0},
        })

    opt.update({
        # Com referência, espaço em cima: o rótulo da linha ("Meta: 85%") vai
        # acima da área do gráfico, e com 8 px era cortado.
        "grid": {"left": largura_rotulo + 8, "right": 56 if rotulos_valor else 16,
                 "top": 26 if referencia else 8, "bottom": 12 if rotulos_valor else 40},
        "xAxis": {
            "type": "value",
            # Com o valor na ponta, o eixo de números é ruído: some, e a
            # escala continua começando no zero.
            "show": not rotulos_valor,
            "min": 0,
            # A linha de referência não estica o eixo no ECharts: com a meta
            # de 85% acima de todas as barras, ela ficava fora do gráfico.
            # Com folga, para o rótulo da linha caber.
            **({"max": round(max(float(ordenado["valor"].max()), float(referencia[1])) * 1.08, 6)}
               if referencia else {}),
            "name": rotulo,
            "nameLocation": "middle",
            "nameGap": 26,
            "nameTextStyle": {"fontSize": _FONTE_PX},
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"lineStyle": {"color": _COR_EIXO}},
            "splitLine": {"lineStyle": {"color": _COR_GRADE}},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": {
            "type": "category",
            "data": [i["name"] for i in itens],
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {
                "fontSize": _FONTE_PX,
                "width": largura_rotulo,
                "overflow": "truncate",
            },
        },
        "series": [{
            "id": "ranking",
            "type": "bar",
            "data": itens,
            "barCategoryGap": "34%" if rotulos_valor else "28%",
            "itemStyle": {"borderRadius": [0, 3, 3, 0]},
            "emphasis": {"itemStyle": {"opacity": 1.0}},
            "cursor": "pointer",
            **({"label": {
                "show": True, "position": "right", "fontSize": _FONTE_PX + 1,
                "fontWeight": 600, "casas": casas, "sufixo": sufixo,
            }} if rotulos_valor else {}),
            **({"markLine": {
                "silent": True, "symbol": "none",
                # Cinza escuro, não o do eixo: a 35% de opacidade a linha sumia
                # na tela (tbbrasil, meta de cura). Serve aos dois temas.
                "lineStyle": {"type": "dashed", "color": "rgba(110,110,110,.95)", "width": 2},
                "label": {"formatter": referencia[0], "position": "end", "fontSize": _FONTE_PX,
                          "fontWeight": 600, "color": "rgba(110,110,110,1)"},
                "data": [{"xAxis": float(referencia[1])}],
            }} if referencia else {}),
        }],
    })
    # O formato pt-BR (vírgula, uma casa) é montado no JavaScript a partir
    # deste rótulo: um `formatter` de texto do ECharts não formata número.
    opt["tooltip"]["rotuloValor"] = rotulo
    opt["tooltip"]["casas"] = casas
    return opt


def composicao(
    dados: pd.DataFrame,
    *,
    rotulo: str,
    cor: str,
    largura_rotulo: int = 220,
    ordem_dos_dados: bool = False,
    orientacao: str = "barra",
    rotulos_valor: bool = False,
    recado_vazio: str | None = None,
) -> dict:
    """Distribuição de uma variável do SINAN, em barras horizontais — ECharts.

    ``rotulos_valor`` escreve o valor na ponta de cada barra, como o boletim
    (hansepe, DFTB); o padrão é sem, como o tbpe e o RecifeTB. Em
    ``orientacao="coluna"`` (os Gráficos 5–7 do boletim) o valor sai sempre.
    ``recado_vazio`` troca o texto de quando não há dado (DFTB).

    Mesmas decisões do `graficos.composicao` Altair: percentual quando a base
    sustenta e contagem quando não (a decisão vem de `leitura.composicao`),
    ordem por frequência salvo variável numérica, o nome da variável como
    título. Ao mudar o recorte, cada categoria desliza para o valor novo —
    casada pelo nome —, e as dez do painel trocam juntas.

    O tooltip vem pronto de cada item (``tooltip``, HTML), formatado em
    pt-BR aqui: o ECharts não formata número por texto.
    """
    opt = _base()
    # `rotulo` vazio deixa o gráfico sem título próprio: desde que cada tópico
    # ganhou linha inteira e título de seção, escrever o nome da
    # variável duas vezes, uma sobre a outra, era só ruído.
    if rotulo:
        opt["title"] = {
            "text": rotulo,
            "left": 0,
            "top": 0,
            "textStyle": {"fontSize": 13, "fontWeight": 600},
        }
    if dados.empty:
        recado = {
            "text": recado_vazio or "Sem registro desta variável no recorte",
            "left": "center", "top": "middle",
            "textStyle": {"fontSize": _FONTE_PX, "fontWeight": "normal"},
        }
        # Com recado próprio, o título fica: diz de que variável é o vazio.
        if recado_vazio and rotulo:
            opt["title"] = [
                {"text": rotulo, "left": 0, "top": 0,
                 "textStyle": {"fontSize": 13, "fontWeight": 600}},
                recado,
            ]
        else:
            opt["title"] = recado
        return opt

    base = dados.copy()
    percentual = "pct" in base.columns and base["pct"].notna().any()
    base["valor"] = pd.to_numeric(base["pct"] if percentual else base["n"], errors="coerce")
    titulo_x = "% dos casos" if percentual else "Casos"

    if not ordem_dos_dados:
        base = base.sort_values("valor", ascending=False)
    if orientacao != "coluna":
        # Eixo de categoria cresce de baixo para cima: o primeiro da lista
        # fica embaixo, então a ordem de leitura se inverte aqui. Em coluna
        # o eixo já corre da esquerda para a direita, e inverter viraria a
        # ordem do boletim de cabeça para baixo.
        base = base.iloc[::-1]

    itens = []
    for linha in base.itertuples(index=False):
        n = getattr(linha, "n", None)
        pct = getattr(linha, "pct", None)
        partes = [f"<b>{linha.categoria}</b>", f"Casos: <b>{ui.formatar_inteiro(None if pd.isna(n) else float(n))}</b>"]
        if percentual and pct is not None and not pd.isna(pct):
            partes.append(f"% dos casos: <b>{ui.formatar_decimal(float(pct), 1)}</b>")
        itens.append({
            "name": str(linha.categoria),
            "value": None if pd.isna(linha.valor) else float(linha.valor),
            "tooltip": "<br/>".join(partes),
        })

    if orientacao == "coluna":
        # O formato dos Gráficos 5, 6 e 7: colunas, eixo preso em 0–100% e o
        # valor escrito em cima. O eixo fixo é o que permite comparar dois
        # recortes sem reler a escala — com eixo automático, uma categoria de
        # 12% num município e 40% em outro desenham a mesma altura de barra.
        maximo = 100 if percentual else None
        opt.update({
            "grid": {
                "left": 56, "right": 16,
                "top": 34 if rotulo else 24, "bottom": 64,
            },
            "xAxis": {
                "type": "category",
                "data": [i["name"] for i in itens],
                "axisLine": {"lineStyle": {"color": _COR_EIXO}},
                "axisTick": {"show": False},
                "axisLabel": {
                    "fontSize": _FONTE_PX,
                    "interval": 0,
                    # 104px cabe "Encaminhamento" numa linha só: com 90 o
                    # ECharts quebrava no meio da palavra, porque "break"
                    # sem espaço para quebrar quebra onde der.
                    "width": 104,
                    "overflow": "break",
                    "lineHeight": 12,
                },
            },
            "yAxis": {
                **_eixo_valor(titulo_x),
                "min": 0,
                **({"max": maximo} if maximo else {}),
            },
            "series": [{
                "id": "composicao",
                "type": "bar",
                "data": itens,
                "barCategoryGap": "30%",
                "itemStyle": {"color": cor, "borderRadius": [2, 2, 0, 0]},
                "label": {
                    "show": True, "position": "top",
                    "fontSize": _FONTE_PX, "casas": 1 if percentual else 0,
                },
            }],
        })
        return opt

    opt.update({
        # Sem título próprio, o topo não precisa da faixa que o abrigava.
        # Com o valor na ponta, a direita precisa de espaço para ele: com 16px
        # o "41,2" da barra mais longa saía cortado pela borda (DFTB).
        "grid": {
            "left": largura_rotulo + 8, "right": 36 if rotulos_valor else 16,
            "top": 34 if rotulo else 8, "bottom": 40,
        },
        "xAxis": {
            "type": "value",
            "name": titulo_x,
            "nameLocation": "middle",
            "nameGap": 26,
            "nameTextStyle": {"fontSize": _FONTE_PX},
            "splitNumber": 5,
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"lineStyle": {"color": _COR_EIXO}},
            "splitLine": {"lineStyle": {"color": _COR_GRADE}},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": {
            "type": "category",
            "data": [i["name"] for i in itens],
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {
                "fontSize": _FONTE_PX,
                "width": largura_rotulo,
                "overflow": "truncate",
            },
        },
        "series": [{
            "id": "composicao",
            "type": "bar",
            "data": itens,
            "barCategoryGap": "30%",
            "itemStyle": {"color": cor, "borderRadius": [0, 2, 2, 0]},
            # O boletim escreve o valor na ponta da barra (Gráficos 8 e 9);
            # sem ele, ler "41,2" exige mirar no eixo.
            **({"label": {
                "show": True, "position": "right",
                "fontSize": _FONTE_PX, "casas": 1 if percentual else 0,
            }} if rotulos_valor else {}),
        }],
    })
    return opt


# ---------------------------------------------------------------------------
# Evolução temporal: canal endêmico, série anual e epicurva
# ---------------------------------------------------------------------------

#: Cores do canal, as mesmas do Altair (`graficos.py`): faixa azul-clara com
#: borda cinza-azulada, anos de referência numa rampa fria do mais antigo ao
#: mais recente, ano selecionado na cor da métrica.
SERIE_ATUAL = "Ano selecionado"
#: Uma entrada só para os cinco anos de referência.
#:
#: A rampa os ordena bem — mais antigo mais claro —, mas não os identifica:
#: anos vizinhos ficam em ΔE 6,4 a 8,4 **em todas as visões, inclusive a
#: normal**, e abrir a rampa não resolve (três alternativas testadas em
#: a melhor chega a 10,2). São cinco degraus numa escala
#: sequencial: não cabem. A legenda prometia escolher um ano pela cor e não
#: entregava. O ano continua nomeado no tooltip, que é onde a identificação
#: funciona — por texto, não por cor.
SERIE_REFERENCIA = "Anos anteriores"
SERIE_Q1 = "Q1"
SERIE_Q3 = "Q3"
COR_FAIXA = "#CBDCEF"
COR_BORDA_FAIXA = "#8FA9C4"
RAMPA_REFERENCIA = ("#C3CBD4", "#A8B6C6", "#8C9FB8", "#6E88AA", "#4A78B0")

#: Nomes das duas séries mudas que desenham a faixa (ver `canal_endemico`).
_FAIXA_BASE = "\u200b"
_FAIXA_ALTURA = "\u200b\u200b"


#: Cinza das categorias que não são classe: "Ignorado", "Não classificada",
#: "Em branco". Fora da rampa de propósito — elas não ocupam posição numa
#: ordem de gravidade, e pintá-las com um tom da rampa sugeriria que sim.
COR_SEM_CLASSE = "#9AA0AA"

#: Palavras que marcam categoria sem classe, comparadas sem acento e em
#: minúscula.
_SEM_CLASSE = ("ignorado", "nao classificada", "nao classificado", "em branco",
               "sem informacao", "nao informado", "ign/branco")


def _sem_classe(categoria: str) -> bool:
    texto = unicodedata.normalize("NFKD", str(categoria).lower())
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return any(marca in texto for marca in _SEM_CLASSE)


def cores_das_categorias(categorias: list[str], base: str) -> dict[str, str]:
    """Uma cor por categoria, do mais claro ao mais escuro na ordem recebida.

    A ordem das categorias é a do campo, que na maioria das variáveis da
    ficha é também uma ordem de gravidade — indeterminada, tuberculoide,
    dimorfa, virchowiana. Usar uma rampa em vez de cores avulsas faz a
    sequência das cores dizer isso, e tem um efeito colateral bom: tons de
    uma rampa diferem em luminosidade, que é o canal que nenhum tipo de
    daltonismo apaga. Com sete categorias empilhadas, cores avulsas de mesma
    luminosidade seriam indistinguíveis.
    """
    com_classe = [c for c in categorias if not _sem_classe(c)]
    if not com_classe:
        return {c: COR_SEM_CLASSE for c in categorias}

    # Escolhe por **luminosidade**, e não por posição na rampa. A rampa não é
    # linear em L*: os três tons escuros ficam entre 29 e 16, e pegar um sim
    # outro não punha duas categorias vizinhas a ΔE 9,6 — indistinguíveis
    # empilhadas uma sobre a outra. Medido com `theme/visao.py`.
    rampa = paleta.rampa(base)
    luz = [paleta.luminosidade(c) for c in rampa]
    alvos = _luminosidades_alvo(max(luz), min(luz), len(com_classe))
    escolhidos = [rampa[min(range(len(luz)), key=lambda i: abs(luz[i] - a))] for a in alvos]
    cores = dict(zip(com_classe, escolhidos, strict=True))
    return {c: cores.get(c, COR_SEM_CLASSE) for c in categorias}


def _luminosidades_alvo(claro: float, escuro: float, quantas: int) -> list[float]:
    """Luminosidades espaçadas por igual, do mais claro ao mais escuro."""
    if quantas == 1:
        return [(claro + escuro) / 2]
    passo = (claro - escuro) / (quantas - 1)
    return [claro - i * passo for i in range(quantas)]


def composicao_por_ano(
    dados: pd.DataFrame,
    *,
    rotulo: str = "",
    cor: str,
    maximo: float | None = 100,
) -> dict:
    """A mesma distribuição, ano a ano, em colunas empilhadas em 100%.

    O gráfico de um ano mostra a fotografia; este mostra o movimento. Pedido
    da equipe parceira em outubro, a partir da forma clínica: entre 2010 e
    2025 a tuberculoide cai de 27% para 8% e a dimorfa sobe de 32% para 45%,
    e nada disso aparece numa barra só.

    Empilhado em 100%, e não colunas lado a lado: o que se compara é a
    **composição**, e o volume de casos muda bastante entre os anos. Lado a
    lado, um ano com metade dos casos pareceria ter metade de tudo.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série para esta variável")

    anos = [str(int(a)) for a in sorted(dados["ano"].unique())]
    # A ordem de empilhamento é a da primeira aparição, que o leitor já
    # ordenou pelo campo. `drop_duplicates` preserva essa ordem.
    categorias = list(dados["categoria"].drop_duplicates())
    cores = cores_das_categorias(categorias, cor)

    series = []
    for categoria in categorias:
        por_ano = dados[dados["categoria"] == categoria].set_index("ano")["pct"]
        series.append({
            "id": f"cat-{categoria}", "name": categoria, "type": "bar",
            "stack": "composicao",
            "data": [_valor(por_ano.get(int(a))) for a in anos],
            "itemStyle": {
                "color": cores[categoria],
                # Fio entre as faixas empilhadas, em cinza médio.
                #
                # Cinco categorias não cabem numa escala sequencial com folga
                # de cor: espaçadas por luminosidade, as vizinhas ficam em
                # ΔE 15 a 19, acima do indistinguível mas abaixo do
                # confortável. É a mesma aritmética da rampa do mapa. O fio
                # resolve por outro canal — a borda existe mesmo quando os
                # dois tons se parecem —, e o cinza médio é o único que
                # contrasta com as duas pontas da rampa e sobrevive aos dois
                # temas.
                "borderColor": "rgba(127,127,127,.7)",
                "borderWidth": 1,
            },
            "barCategoryGap": "22%",
        })
    series[-1]["itemStyle"]["borderRadius"] = [2, 2, 0, 0]

    opt.update({
        "grid": {"left": 56, "right": 16, "top": 16, "bottom": 64},
        "xAxis": _eixo_categoria(anos) | {"name": "Ano", "nameLocation": "middle",
                                          "nameGap": 28},
        "yAxis": _eixo_valor("% dos casos") | ({"max": maximo} if maximo else {}),
        "series": series,
        "legend": {
            "data": categorias, "bottom": 0, "left": "center", "icon": "roundRect",
            "itemWidth": 12, "itemHeight": 10,
            "textStyle": {"fontSize": _FONTE_PX, "fontWeight": "normal"},
        },
        "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"},
                    "rotuloValor": "%", "casas": 1},
    })
    if rotulo:
        opt["title"] = {"text": rotulo, "left": 0, "top": 0,
                        "textStyle": {"fontSize": 13, "fontWeight": 600}}
    return opt


def _eixo_valor(rotulo: str) -> dict:
    return {
        "type": "value",
        "name": rotulo,
        "nameLocation": "middle",
        "nameGap": 40,
        "nameTextStyle": {"fontSize": _FONTE_PX},
        "axisLine": {"show": False},
        "axisTick": {"show": False},
        "splitLine": {"lineStyle": {"color": _COR_GRADE}},
        "axisLabel": {"fontSize": _FONTE_PX},
    }


def _eixo_categoria(rotulos: list[str]) -> dict:
    return {
        "type": "category",
        "data": rotulos,
        "boundaryGap": False,
        "axisLine": {"lineStyle": {"color": _COR_EIXO}},
        "axisTick": {"lineStyle": {"color": _COR_EIXO}},
        "axisLabel": {"fontSize": _FONTE_PX},
    }


def _com_alfa(cor: str, alfa: float) -> str:
    """`#RRGGBB` com transparência, no formato que o ECharts aceita."""
    texto = cor.lstrip("#")
    r, g, b = (int(texto[i : i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alfa})"


def _valor(v) -> float | None:
    return None if v is None or pd.isna(v) else float(v)


def _recado(opt: dict, texto: str) -> dict:
    opt["title"] = {
        "text": texto,
        "left": "center", "top": "middle",
        "textStyle": {"fontSize": _FONTE_PX, "fontWeight": "normal"},
    }
    return opt


def canal_endemico(canal, *, rotulo: str, cor: str, anos_agrupados: bool = False) -> dict:
    """Canal endêmico em ECharts: ano corrente sobre a faixa interquartil.

    ``anos_agrupados`` põe os anos de referência numa entrada só da legenda
    ("Anos anteriores"), que não liga nem desliga nada — o hansepe e o DFTB
    usam. O padrão lista cada ano, como o tbpe e o RecifeTB sempre fizeram:
    é escolha visual de cada painel, não correção.

    A faixa é o truque que o painel de origem (também ECharts) usa: duas
    séries empilhadas — uma invisível no Q1 e outra com a altura Q3 − Q1 e
    área pintada —, porque a biblioteca não desenha área entre duas linhas
    arbitrárias. As duas ficam fora da legenda e do tooltip (`ocultas`).

    O que o ECharts dá em troca: ao mudar o recorte, a linha do ano e a faixa
    **deslizam** para os valores novos; os anos de referência entram e saem
    com transição. Séries com `id` fixo por papel (`atual`, `q1`, `q3`,
    `ref-<ano>`) para o casamento entre renders.

    Tooltip unificado por mês (trigger ``axis``), como no Altair: comparar
    março de 2024 com março de 2021 não pode depender de pontaria.
    """
    opt = _base()
    if getattr(canal, "vazio", True):
        return _recado(opt, "Sem série mensal para montar o canal")

    atual = canal.atual.sort_values("mes")
    meses = [str(m)[:3].capitalize() for m in atual["mes_nome"]]
    faixa = canal.faixa.set_index("mes").reindex(atual["mes"])
    anos = [int(a) for a in canal.anos]
    rampa = list(RAMPA_REFERENCIA[-len(anos):]) if anos else []

    q1 = [_valor(v) for v in faixa["q1"]]
    q3 = [_valor(v) for v in faixa["q3"]]
    altura_faixa = [
        None if a is None or b is None else max(b - a, 0.0)
        for a, b in zip(q1, q3, strict=True)
    ]

    series: list[dict] = [
        {
            "id": "faixa-base", "name": _FAIXA_BASE, "type": "line", "stack": "faixa",
            "data": q1, "symbol": "none", "lineStyle": {"opacity": 0},
            "silent": True, "z": 1,
        },
        {
            "id": "faixa", "name": _FAIXA_ALTURA, "type": "line", "stack": "faixa",
            "data": altura_faixa, "symbol": "none", "lineStyle": {"opacity": 0},
            "areaStyle": {"color": COR_FAIXA, "opacity": 0.85}, "silent": True, "z": 1,
        },
    ]
    for nome, dados_serie, ident in ((SERIE_Q1, q1, "q1"), (SERIE_Q3, q3, "q3")):
        series.append({
            "id": ident, "name": nome, "type": "line", "data": dados_serie,
            "symbol": "circle", "symbolSize": 4,
            "lineStyle": {"width": 1.5, "color": COR_BORDA_FAIXA},
            "itemStyle": {"color": COR_BORDA_FAIXA}, "z": 2,
        })
    if not canal.referencia.empty:
        for ano, tom in zip(anos, rampa, strict=True):
            grupo = (
                canal.referencia[canal.referencia["ano"] == ano]
                .set_index("mes").reindex(atual["mes"])
            )
            series.append({
                "id": f"ref-{ano}", "name": str(ano), "type": "line",
                "data": [_valor(v) for v in grupo["valor"]],
                "symbol": "none",
                "lineStyle": {"width": 1.3, "type": [4, 3], "color": tom},
                "itemStyle": {"color": tom}, "z": 3,
            })
    if anos and anos_agrupados:
        # Série sem dado, só para a legenda ter uma entrada do grupo. O tom é
        # o do meio da rampa, que representa o conjunto melhor que a ponta.
        series.append({
            "id": "ref-grupo", "name": SERIE_REFERENCIA, "type": "line", "data": [],
            "symbol": "none",
            "lineStyle": {"width": 1.3, "type": [4, 3], "color": rampa[len(rampa) // 2]},
            "itemStyle": {"color": rampa[len(rampa) // 2]}, "silent": True,
        })
    series.append({
        "id": "atual", "name": SERIE_ATUAL, "type": "line",
        "data": [_valor(v) for v in atual["valor"]],
        "symbol": "circle", "symbolSize": 7,
        "lineStyle": {"width": 2.8, "color": cor}, "itemStyle": {"color": cor}, "z": 5,
    })

    referencia = ([SERIE_REFERENCIA] if anos else []) if anos_agrupados else [str(a) for a in anos]
    legenda = [SERIE_ATUAL, *referencia, SERIE_Q1, SERIE_Q3]
    opt.update({
        "grid": {"left": 56, "right": 16, "top": 40, "bottom": 32},
        "legend": {
            "data": legenda, "top": 0, "left": 0, "icon": "roundRect",
            "itemWidth": 14, "itemHeight": 3, "textStyle": {"fontSize": _FONTE_PX},
            # Chave, não controle: "Anos anteriores" não tem série própria
            # para ligar e desligar, e um clique que não faz nada é pior do
            # que clique nenhum. Com cada ano na legenda, o clique liga e
            # desliga o ano, e aí vale.
            **({"selectedMode": False} if anos_agrupados else {}),
        },
        "xAxis": _eixo_categoria(meses),
        "yAxis": _eixo_valor(rotulo),
        "series": series,
    })
    opt["tooltip"].update({
        "trigger": "axis",
        "axisPointer": {"type": "line", "lineStyle": {"color": "rgba(128,128,128,.55)"}},
        "ocultas": [_FAIXA_BASE, _FAIXA_ALTURA],
        "casas": 2,
    })
    return opt


def evolucao_anual(dados: pd.DataFrame, *, rotulo: str, cor: str, ano: int) -> dict:
    """Série histórica anual em barras, com o ano selecionado destacado."""
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série histórica para este recorte")
    base = dados.sort_values("ano")
    itens = [
        {
            "name": str(int(a)), "value": _valor(v),
            "itemStyle": {"opacity": 1.0 if int(a) == int(ano) else 0.45},
        }
        for a, v in zip(base["ano"], base["valor"], strict=True)
    ]
    opt.update({
        "grid": {"left": 56, "right": 16, "top": 16, "bottom": 32},
        "xAxis": {
            "type": "category", "data": [i["name"] for i in itens],
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": _eixo_valor(rotulo),
        "series": [{
            "id": "anual", "type": "bar", "data": itens,
            "itemStyle": {"color": cor, "borderRadius": [3, 3, 0, 0]},
            "barCategoryGap": "25%",
        }],
    })
    opt["tooltip"].update({"rotuloValor": rotulo, "casas": 1})
    return opt


def indicador_anual(
    dados: pd.DataFrame,
    *,
    rotulo: str,
    cor: str,
    ano: int,
    coluna: str = "pct",
    maximo: float | None = 100,
    casas: int = 1,
    tipo: str = "barra",
) -> dict:
    """Indicador em percentual por ano, no formato dos Gráficos 10 a 13.

    O boletim desenha esses indicadores sempre igual: barras por ano, eixo
    fixo de 0 a 100 e o valor escrito em cima de cada barra. O eixo fixo é o
    que permite comparar o gráfico de cura com o de abandono sem reler a
    escala — e é também o que impede que uma variação de dois pontos pareça
    um despencar, que é o risco do eixo automático.

    Ano sem valor (coorte aberta) fica com a barra vazia em vez de sumir: a
    lacuna é informação, e apagá-la daria a impressão de série que terminou.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série para este recorte")
    base = dados.sort_values("ano")
    itens = [
        {
            "name": str(int(a)), "value": _valor(v),
            "itemStyle": {"opacity": 1.0 if int(a) == int(ano) else 0.55},
        }
        for a, v in zip(base["ano"], base[coluna], strict=True)
    ]
    opt.update({
        "grid": {"left": 56, "right": 16, "top": 24, "bottom": 32},
        "xAxis": {
            "type": "category", "data": [i["name"] for i in itens],
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": {**_eixo_valor(rotulo), "min": 0, **({"max": maximo} if maximo else {})},
        "series": [{
            "id": "indicador",
            "type": "line" if tipo == "linha" else "bar",
            "data": itens,
            "itemStyle": {
                "color": cor,
                **({} if tipo == "linha" else {"borderRadius": [3, 3, 0, 0]}),
            },
            "barCategoryGap": "30%",
            # Marcador quadrado e linha de 2px: é como o boletim desenha o
            # Gráfico 10. O quadrado distingue o ponto da linha de grade sem
            # depender da cor.
            **({
                "symbol": "rect", "symbolSize": 8,
                "lineStyle": {"width": 2, "color": cor},
            } if tipo == "linha" else {}),
            "label": {
                "show": True, "position": "top",
                "fontSize": _FONTE_PX, "casas": casas,
            },
        }],
    })
    opt["tooltip"].update({"rotuloValor": rotulo, "casas": casas})
    return opt


def comparativo_anual(
    dados: pd.DataFrame,
    *,
    series: dict[str, tuple[str, str]],
    rotulo: str = "Proporção (%)",
    maximo: float | None = 100,
    casas: int = 1,
) -> dict:
    """Dois indicadores lado a lado por ano — o formato dos Gráficos 11 e 13.

    ``series`` é ``coluna → (rótulo, cor)``. O boletim desenha cura e
    abandono, e GIF no diagnóstico e na cura, como barras agrupadas no mesmo
    eixo de 0 a 100, com o valor em cima de cada uma e a legenda embaixo.

    Eixo fixo, como no documento: é ele que deixa comparar o gráfico de cura
    com o de abandono sem reler a escala, e que impede uma variação de dois
    pontos de parecer um tombo.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série para este recorte")
    base = dados.sort_values("ano")
    anos = [str(int(a)) for a in base["ano"]]

    desenhos = []
    for coluna, (nome, cor) in series.items():
        desenhos.append({
            "id": f"indicador-{coluna}", "name": nome, "type": "bar",
            "data": [
                {"name": a, "value": _valor(v)}
                for a, v in zip(anos, base[coluna], strict=True)
            ],
            "itemStyle": {"color": cor, "borderRadius": [3, 3, 0, 0]},
            "barCategoryGap": "34%",
            "label": {
                "show": True, "position": "top",
                "fontSize": _FONTE_PX, "casas": casas,
            },
        })

    opt.update({
        "grid": {"left": 56, "right": 16, "top": 24, "bottom": 56},
        "xAxis": {
            "type": "category", "data": anos,
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": {**_eixo_valor(rotulo), "min": 0, **({"max": maximo} if maximo else {})},
        "legend": {
            "data": [nome for nome, _ in series.values()],
            "bottom": 0, "left": "center",
            "icon": "roundRect", "itemWidth": 12, "itemHeight": 12,
            "textStyle": {"fontSize": _FONTE_PX},
        },
        "series": desenhos,
    })
    opt["tooltip"].update({
        "trigger": "axis",
        "axisPointer": {"type": "shadow"},
        "ocultas": [],
        "casas": casas,
    })
    return opt


def epicurva(dados: pd.DataFrame, *, rotulo: str, cor: str,
             rotulo_x: str = "", ano_em_foco: int | None = None,
             area: bool = False) -> dict:
    """Série mensal contínua, atravessando os anos, com o ano em foco grosso.

    ``area`` pinta a área sob a linha (hansepe, DFTB); o padrão é só a linha,
    como o tbpe e o RecifeTB. ``rotulo_x`` dá nome ao eixo do tempo.

    Eixo de tempo (não categoria): são ~180 pontos, e o ECharts escolhe os
    anos para rotular. O trecho do ano selecionado é uma segunda série sobre
    a primeira, mais grossa — ao trocar o ano, o destaque desliza.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série mensal para este recorte")
    base = dados.sort_values(["ano", "mes"])

    def pontos(df: pd.DataFrame) -> list:
        return [
            [f"{int(a)}-{int(m):02d}-01", _valor(c)]
            for a, m, c in zip(df["ano"], df["mes"], df["casos"], strict=True)
        ]

    nome_foco = f"{rotulo} em {ano_em_foco}"
    series = [{
        "id": "serie", "name": rotulo, "type": "line", "data": pontos(base),
        "symbol": "circle", "symbolSize": 6, "showSymbol": False,
        "lineStyle": {"width": 1.6, "color": cor}, "itemStyle": {"color": cor},
        # Área sob a linha, como num gráfico de cotação: a série é uma
        # contagem que parte do zero, e o preenchimento mostra isso sem
        # precisar de segunda escala. Desce a transparente para não virar
        # bloco de cor atrás dos rótulos do eixo.
        **({"areaStyle": {
            "color": {
                "type": "linear", "x": 0, "y": 0, "x2": 0, "y2": 1,
                "colorStops": [
                    {"offset": 0, "color": _com_alfa(cor, 0.30)},
                    {"offset": 1, "color": _com_alfa(cor, 0.02)},
                ],
            }
        }} if area else {}),
    }]
    if ano_em_foco is not None:
        foco = base[base["ano"] == ano_em_foco]
        if not foco.empty:
            series.append({
                "id": "foco", "name": nome_foco, "type": "line", "data": pontos(foco),
                "symbol": "none", "lineStyle": {"width": 3, "color": cor},
                "itemStyle": {"color": cor}, "z": 3,
            })
    opt.update({
        # Mais fundo quando o eixo tem nome: ele é escrito abaixo dos anos,
        # e com os 32px de antes ficaria por cima deles.
        "grid": {"left": 56, "right": 16, "top": 12,
                 "bottom": 48 if rotulo_x else 32},
        "xAxis": {
            "type": "time",
            # `rotulo_x` vem de fora, e não escrito aqui: o que o eixo conta
            # é propriedade da extração, não do desenho. Em PE o ano das
            # tabelas é o de notificação, conferido em 25.843 de 25.843
            # registros do microdado; outro painel da família pode receber
            # outra coisa.
            **({"name": rotulo_x, "nameLocation": "middle", "nameGap": 26,
                "nameTextStyle": {"fontSize": _FONTE_PX}} if rotulo_x else {}),
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"lineStyle": {"color": _COR_EIXO}},
            "axisLabel": {"fontSize": _FONTE_PX, "formatter": "{yyyy}"},
            "splitLine": {"show": False},
        },
        "yAxis": _eixo_valor(rotulo),
        "series": series,
    })
    opt["tooltip"].update({
        "trigger": "axis",
        # Mira tracejada, que é como os gráficos de série temporal marcam o
        # ponto sob o cursor — a linha cheia se confunde com a própria série.
        "axisPointer": {
            "type": "line",
            "lineStyle": {
                "color": "rgba(128,128,128,.7)", "width": 1, "type": "dashed",
            },
        },
        "ocultas": [nome_foco],
        "casas": 0,
        "mesNoEixo": True,
    })
    return opt


# ---------------------------------------------------------------------------
# Pirâmide etária
# ---------------------------------------------------------------------------

#: Cores dos dois lados, as mesmas do Altair: deliberadamente não é rosa e
#: azul, e o azul da mortalidade já está tomado.
COR_HOMENS = "#1C5D99"
COR_MULHERES = "#B8860B"


def piramide(dados: pd.DataFrame, *, rotulo: str, por_100mil: bool = False) -> dict:
    """Pirâmide etária em ECharts: homens à esquerda, mulheres à direita.

    Escala única e simétrica, como no Altair: em tuberculose os homens somam
    quase o triplo das mulheres, e sem simetria o eixo cresce só para a
    esquerda e o excesso masculino — o achado — vira efeito de escala. Os
    valores dos homens vão negativos para ficarem à esquerda; o eixo e o
    tooltip mostram o módulo (`absoluto`, montado no JavaScript).

    Duas séries com `id` fixo (`homens`, `mulheres`), itens casados pela
    faixa etária: ao mudar o recorte, cada barra desliza para o valor novo.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem dado por faixa etária para este recorte")

    base = dados.copy()
    if por_100mil:
        pop = pd.to_numeric(base["pop"], errors="coerce")
        base["valor"] = (base["valor"] / pop * 100_000).where(pop > 0)
        base = base.dropna(subset=["valor"])
        if base.empty:
            return _recado(opt, "Sem população para calcular a taxa")
        rotulo = f"{rotulo} por 100 mil hab."
    casas = 1 if por_100mil else 0

    faixas = [f for _, f in sorted({(r.faixa_ord, r.faixa_etaria) for r in base.itertuples()})]
    por_sexo = {
        sexo: base[base["sexo"] == sexo].set_index("faixa_etaria")["valor"].reindex(faixas)
        for sexo in ("M", "F")
    }
    limite = float(pd.to_numeric(base["valor"], errors="coerce").abs().max() or 0) or 1.0

    def serie(ident, nome, sexo, cor, sinal):
        return {
            "id": ident, "name": nome, "type": "bar", "stack": "piramide",
            "data": [
                {"name": faixa, "value": None if pd.isna(v) else sinal * float(v)}
                for faixa, v in por_sexo[sexo].items()
            ],
            "itemStyle": {"color": cor},
            "barCategoryGap": "22%",
        }

    opt.update({
        "grid": {"left": 112, "right": 16, "top": 34, "bottom": 40},
        "legend": {
            "data": ["Homens", "Mulheres"], "top": 0, "left": 0,
            "icon": "roundRect", "itemWidth": 12, "itemHeight": 12,
            "textStyle": {"fontSize": _FONTE_PX},
        },
        "xAxis": {
            **_eixo_valor(rotulo),
            "min": -limite, "max": limite,
            "nameGap": 26,
            "absoluto": True,
        },
        "yAxis": {
            "type": "category",
            "data": faixas,
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX, "interval": 0},
        },
        "series": [
            serie("homens", "Homens", "M", COR_HOMENS, -1),
            serie("mulheres", "Mulheres", "F", COR_MULHERES, 1),
        ],
    })
    opt["tooltip"].update({"rotuloValor": rotulo, "casas": casas, "absoluto": True})
    return opt


# ---------------------------------------------------------------------------
# Barras empilhadas por ano com linha em eixo próprio (rodapé da hanseníase)
# ---------------------------------------------------------------------------


def barras_empilhadas_com_linha(
    dados: pd.DataFrame,
    *,
    barras: dict[str, str],
    linha: str,
    rotulo_linha: str,
    cores: dict[str, str],
    cor_linha: str,
    casas_linha: int = 1,
    legenda: bool = True,
    rotulos: bool = False,
) -> dict:
    """Barras empilhadas por ano com uma linha em eixo próprio à direita.

    É o formato dos dois gráficos de rodapé do painel de origem: MB e PB
    empilhados com a proporção MB em linha; casos 0–14 com a taxa em linha.
    ``barras`` é ``coluna → rótulo``; ``linha`` é a coluna da linha. Séries
    com `id` fixo por coluna: ao mudar o recorte, barras e linha deslizam.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série para este recorte")
    base = dados.sort_values("ano")
    anos = [str(int(a)) for a in base["ano"]]

    series = []
    for coluna, rotulo in barras.items():
        series.append({
            "id": f"barra-{coluna}", "name": rotulo, "type": "bar", "stack": "anos",
            "data": [{"name": a, "value": _valor(v)} for a, v in zip(anos, base[coluna], strict=True)],
            "itemStyle": {"color": cores[coluna]},
            "barCategoryGap": "30%",
            # O boletim escreve o N **dentro** da barra, em branco, rente à
            # base (Gráficos 1 e 2). Em cima ele colidiria com o rótulo da
            # linha, que passa por ali.
            **({"label": {
                "show": True, "position": "insideBottom", "distance": 6,
                "color": cor_sobre(cores[coluna]), "fontSize": _FONTE_PX,
                "casas": 0,
            }} if rotulos else {}),
        })
    # Só a última fatia da pilha leva o canto arredondado, senão cada fatia
    # fecha em arco e a pilha fica com "juntas".
    series[-1]["itemStyle"]["borderRadius"] = [2, 2, 0, 0]
    series.append({
        "id": "linha", "name": rotulo_linha, "type": "line", "yAxisIndex": 1,
        "data": [{"name": a, "value": _valor(v)} for a, v in zip(anos, base[linha], strict=True)],
        "symbol": "rect", "symbolSize": 7,
        "lineStyle": {"width": 2, "color": cor_linha}, "itemStyle": {"color": cor_linha},
        "z": 4,
        **({"label": {
            "show": True, "position": "top",
            "fontSize": _FONTE_PX, "casas": casas_linha,
        }} if rotulos else {}),
    })

    opt.update({
        # Legenda embaixo e centrada, como no boletim (Gráficos 1, 2, 11 e
        # 13) — não no topo à esquerda, e não na calha: ali fica só a régua do
        # Ministério. O topo sobra para o rótulo que a linha escreve.
        "grid": {
            "left": 56, "right": 64,
            "top": 24, "bottom": 56 if legenda else 32,
        },
        "legend": {
            "show": legenda,
            "data": [*barras.values(), rotulo_linha],
            "bottom": 0, "left": "center",
            "icon": "roundRect", "itemWidth": 12, "itemHeight": 12,
            "textStyle": {"fontSize": _FONTE_PX},
        },
        "xAxis": {
            "type": "category", "data": anos, "name": "Ano",
            "nameLocation": "middle", "nameGap": 22,
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": [
            _eixo_valor("Casos"),
            {**_eixo_valor(rotulo_linha), "position": "right", "splitLine": {"show": False}},
        ],
        "series": series,
    })
    opt["tooltip"].update({
        "trigger": "axis",
        "axisPointer": {"type": "shadow"},
        "ocultas": [],
        "casas": casas_linha,
        "casasPorSerie": {rotulo_linha: casas_linha, **{r: 0 for r in barras.values()}},
    })
    return opt


# ---------------------------------------------------------------------------
# Do RecifeTB: recado avulso e casos por mês do bairro
# ---------------------------------------------------------------------------

def recado(texto: str) -> dict:
    """Gráfico vazio com um recado, no lugar de um painel em branco."""
    return _recado(_base(), texto)


def evolucao_mensal(dados: pd.DataFrame, *, rotulo: str, cor: str) -> dict:
    """Casos por mês do ano selecionado, em barras.

    É o que o bairro mostra no lugar do canal endêmico: taxa mensal por
    bairro exigiria população por bairro e mês, que não existe na origem.
    Itens casados pelo mês: ao trocar de bairro, cada barra desliza.
    """
    opt = _base()
    if dados.empty:
        return _recado(opt, "Sem série mensal para este recorte")
    base = dados.sort_values("mes")
    meses = [str(m)[:3].capitalize() for m in base["mes_nome"]]
    itens = [
        {"name": m, "value": _valor(v), "tooltip": f"<b>{nome}</b><br/>{rotulo}: <b>{ui.formatar_inteiro(_valor(v))}</b>"}
        for m, nome, v in zip(meses, base["mes_nome"], base["valor"], strict=True)
    ]
    opt.update({
        "grid": {"left": 56, "right": 16, "top": 16, "bottom": 32},
        "xAxis": {
            "type": "category", "data": meses,
            "axisLine": {"lineStyle": {"color": _COR_EIXO}},
            "axisTick": {"show": False},
            "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": _eixo_valor(rotulo),
        "series": [{
            "id": "mensal", "type": "bar", "data": itens,
            "itemStyle": {"color": cor, "borderRadius": [3, 3, 0, 0]},
            "barCategoryGap": "25%",
        }],
    })
    return opt


# ---------------------------------------------------------------------------
# Layout que o app.py usa para dimensionar os componentes
# ---------------------------------------------------------------------------

#: Faixa vertical por barra do ranking, na **área de plotagem**.
#:
#: Medido no navegador: a caixa do rótulo tem 16px de altura com a fonte de
#: 12px, e o Vega esconde um nome sim outro não assim que o passo entre eles
#: fica abaixo disso. Com 27 UFs em 512px de área útil o passo caía para
#: 15,3px — colidia por menos de um pixel, e metade dos nomes sumia.
#:
#: 22 deixa 6px de folga sobre a caixa, o bastante para a variação de métrica
#: de fonte entre navegadores.
ALTURA_BARRA_RANKING = 22

#: Altura que o eixo x, seu título e as margens comem antes de sobrar espaço
#: para as barras. Medido no navegador: 594px de gráfico davam 512px de área
#: de plotagem.
#:
#: Entra na conta porque a primeira tentativa de conserto reservou 22px por
#: barra sobre a altura **total** e continuou escondendo nomes — as faixas
#: recebiam 19px, não 22.
ALTURA_EIXO_RANKING = 82

#: Piso do ranking, para uma lista de 5 não virar uma tira.
ALTURA_MIN_RANKING = 180

#: Espaço para o nome no eixo do ranking, em pixels.
#:
#: **O critério não é estética, é identificação.** Cortado curto demais, dois
#: municípios diferentes da mesma UF viram o mesmo texto, e o ranking deixa de
#: dizer de quem é a barra. Medido sobre os 5.571 nomes, com a largura de
#: :data:`PX_POR_CARACTERE`:
#:
#: ====== ======== =========
#: limite cortados ambíguos
#: ====== ======== =========
#: 98         891        49
#: 120        429         4
#: **150**     23         0
#: 175          2         0
#: ====== ======== =========
#:
#: 98 era o que o Vega dava sozinho, e ali "São Domingos do Maranhão" e "São
#: Domingos do Azeitão" apareciam idênticos. 150 é o **menor** valor onde
#: nenhum par colide; os 23 que ainda cortam continuam únicos, e o nome
#: inteiro está no tooltip. Subir para 175 salvaria dois nomes e custaria 25px
#: de barra a todo mundo.
LARGURA_ROTULO_RANKING = 150

#: Largura média de um caractere do rótulo, medida no navegador com a fonte de
#: 12px do tema: "José Gonçalves de Minas" ocupa 132px em 23 caracteres.
#:
#: Serve para o teste conferir a propriedade de identificação sem abrir um
#: navegador. É aproximação — nome cheio de "i" ocupa menos que um de "m" —,
#: mas o erro é da ordem de um caractere e a margem entre 150 e o primeiro
#: valor que colide (120) é de seis.
PX_POR_CARACTERE = 5.74


#: Espaço vertical de cada barra da composição.
ALTURA_BARRA_COMPOSICAO = 30

#: Espaço que não é barra: título, eixo x e o rótulo do eixo.
#:
#: **Precisa entrar na conta separado.** A primeira versão da grade usava
#: `max(altura, 30 * n)`, e com cinco categorias isso dava exatamente os 150px
#: pedidos pelo painel — os mesmos 150 de um gráfico de três. Como o cromo come
#: os primeiros 85, sobravam 65px para cinco barras, 13 cada, e os rótulos
#: encavalavam. O sintoma era só em "Tipo de entrada", que é a variável com
#: mais categorias entre as dez que abrem.
CROMO_COMPOSICAO = 85


def altura_composicao(categorias: int) -> int:
    """Altura total de um gráfico de composição com ``categorias`` barras."""
    return CROMO_COMPOSICAO + ALTURA_BARRA_COMPOSICAO * max(categorias, 1)


# ---------------------------------------------------------------------------
# Retrato de uma geografia (0.13.0) — faixa, velocímetro e teia
#
# Os três vieram da aba "Município" da Análise de Mortalidade do tbbrasil:
# gráficos para olhar e entender num relance, no estilo de jornalismo de
# dados, com a disciplina do boletim — valor escrito, um destaque só, o resto
# em cinza.
# ---------------------------------------------------------------------------

#: Cinza dos pontos que não são o destaque, na faixa.
_CINZA_FUNDO = "rgba(120,128,138,.35)"


def faixa(
    valores: pd.Series,
    *,
    destaque: str | None,
    rotulo: str,
    cor: str,
    casas: int = 1,
    texto_destaque: str | None = None,
    maximo: float | None = None,
) -> dict:
    """Todas as geografias como pontos numa faixa, e uma acesa.

    ``valores`` é indexado pelo **nome** que o clique devolve (o mesmo do
    ranking); o x é o valor, o y só espalha os pontos para não se
    sobreporem. O ``destaque`` (nome) sai grande, na ``cor``, com
    ``texto_destaque`` em cima ("3º de 5.570"). Clicar em qualquer ponto
    devolve o nome dele, como no ranking.

    É o gráfico do "onde esta cidade está no país inteiro": milhares de
    pontos cinza e um só aceso, sem eixo para decifrar.
    """
    opt = _base()
    serie = valores.dropna()
    # **Compacta.** Um objeto por ponto ({"value": [x, y], "name": …}) dava
    # 360 KB por interação com 5.570 municípios. Vão só duas listas, e o y —
    # que só espalha — nasce no JS a partir da posição. A ordem é pelo nome,
    # para cada ponto cair sempre no mesmo lugar e a faixa não "tremer".
    fundo = serie[serie.index != destaque].sort_index()
    series = [{
        "id": "faixa", "type": "scatter", "symbolSize": 5,
        "faixa": {"valores": [round(float(v), 1) for v in fundo.to_numpy()],
                  "nomes": [str(n) for n in fundo.index]},
        "itemStyle": {"color": _CINZA_FUNDO}, "cursor": "pointer",
        "emphasis": {"itemStyle": {"color": cor}},
    }]
    if destaque is not None and destaque in serie.index:
        valor = float(serie[destaque])
        # O texto vai para dentro perto das bordas: o 1º do país fica na
        # ponta direita, e "1º de 5.570" em cima dele saía cortado.
        topo = float(maximo if maximo is not None else serie.max()) or 1.0
        lado = "left" if valor > 0.82 * topo else "right" if valor < 0.18 * topo else "top"
        series.append({
            "id": "destaque", "type": "scatter", "symbolSize": 18, "z": 10,
            "data": [{"value": [valor, 0], "name": str(destaque)}],
            "itemStyle": {"color": cor, "borderColor": "#fff", "borderWidth": 2,
                          "shadowBlur": 10, "shadowColor": "rgba(0,0,0,.25)"},
            "label": {"show": bool(texto_destaque), "formatter": texto_destaque or "",
                      "position": lado, "distance": 12, "fontSize": 15, "fontWeight": 700,
                      "color": cor},
            "markLine": {"silent": True, "symbol": "none", "label": {"show": False},
                         "lineStyle": {"color": cor, "width": 2, "type": "solid"},
                         "data": [{"xAxis": valor}]},
        })
    opt.update({
        # 20 à direita: com 8, o "100" do fim do eixo saía cortado.
        "grid": {"left": 12, "right": 20, "top": 40, "bottom": 32},
        "xAxis": {
            "type": "value", "min": 0, **({"max": maximo} if maximo is not None else {}),
            "name": rotulo, "nameLocation": "middle", "nameGap": 22,
            "nameTextStyle": {"fontSize": _FONTE_PX},
            "axisLine": {"show": False}, "axisTick": {"show": False},
            "splitLine": {"show": False}, "axisLabel": {"fontSize": _FONTE_PX},
        },
        "yAxis": {"type": "value", "min": -1.3, "max": 1.3, "show": False},
        "series": series,
    })
    # O x é o valor; o y só espalha — o tooltip mostra o primeiro.
    opt["tooltip"].update({"rotuloValor": rotulo, "casas": casas, "indiceValor": 0})
    return opt


def medidor(
    valor: float | None,
    *,
    cortes: list[float],
    cores: list[str],
    rotulo: str,
    casas: int = 1,
    maximo: float = 100,
) -> dict:
    """Velocímetro de 0 a ``maximo``, com as faixas coloridas e o ponteiro.

    ``cortes`` são os inícios das faixas (o primeiro é 0) e ``cores`` a cor de
    cada uma — a régua do mapa, para o arco e a legenda falarem a mesma
    língua. O número sai grande no centro, em pt-BR, e o ponteiro gira
    quando a geografia muda.
    """
    if len(cortes) != len(cores):
        raise ValueError("um corte por cor")
    limites = [*cortes[1:], maximo]
    arco = [[round(fim / maximo, 4), c] for fim, c in zip(limites, cores, strict=True)]
    opt = _base()
    opt["tooltip"] = {"show": False}
    opt["series"] = [{
        "id": "medidor", "type": "gauge", "min": 0, "max": maximo,
        "startAngle": 205, "endAngle": -25, "radius": "92%", "center": ["50%", "62%"],
        "axisLine": {"lineStyle": {"width": 18, "color": arco}},
        "pointer": {"length": "62%", "width": 6, "itemStyle": {"color": "auto"}},
        "anchor": {"show": True, "size": 14, "itemStyle": {"color": "#12222B"}},
        "axisTick": {"show": False},
        "splitLine": {"length": 18, "distance": -18, "lineStyle": {"color": "#fff", "width": 3}},
        "axisLabel": {"distance": 24, "fontSize": _FONTE_PX},
        "title": {"offsetCenter": [0, "58%"], "fontSize": _FONTE_PX + 1},
        # O número em pt-BR nasce no JS (`detail.casas`): "98,8", não "98.8".
        "detail": {"valueAnimation": True, "offsetCenter": [0, "30%"], "fontSize": 34,
                   "fontWeight": 700, "casas": casas},
        "data": [{"value": None if valor is None else round(float(valor), casas), "name": rotulo}],
    }]
    return opt


def teia(
    eixos: list[tuple[str, float]],
    series: list[tuple[str, list[float], str]],
) -> dict:
    """Teia (radar): o "retrato" de uma geografia em vários componentes.

    ``eixos`` é ``(nome, máximo)`` de cada componente; ``series`` é
    ``(nome, valores, cor)``, na ordem dos eixos — a geografia e a
    referência (a média do país). A primeira série é o destaque: área
    preenchida na cor dela; as demais vêm tracejadas e quase transparentes,
    por trás. Ao trocar de geografia, a forma se transforma.

    Leitura de formato, não de valor exato — a área de uma teia engana. O
    painel deve ter o valor escrito em algum lugar também.
    """
    opt = _base()
    opt["tooltip"] = {"show": False}
    dados = []
    for i, (nome, valores, cor) in enumerate(series):
        principal = i == 0
        dados.append({
            "name": nome, "value": [round(float(v), 3) for v in valores],
            "symbol": "circle", "symbolSize": 5 if principal else 0,
            "lineStyle": {"color": cor, "width": 2.5 if principal else 1.5,
                          "type": "solid" if principal else "dashed"},
            "itemStyle": {"color": cor},
            "areaStyle": {"color": cor, "opacity": 0.28 if principal else 0.08},
        })
    opt.update({
        "legend": {"bottom": 0, "data": [s[0] for s in series], "textStyle": {"fontSize": _FONTE_PX},
                   "itemWidth": 14, "itemHeight": 8},
        "radar": {
            "indicator": [{"name": n, "max": m} for n, m in eixos],
            # 56% deixa lugar para os nomes dos eixos laterais numa coluna
            # estreita; com 64%, "Certeza do risco" saía cortado.
            "radius": "56%", "center": ["50%", "47%"], "splitNumber": 4,
            "axisName": {"fontSize": _FONTE_PX - 1},
            "splitArea": {"show": False},
            "splitLine": {"lineStyle": {"color": _COR_GRADE}},
            "axisLine": {"lineStyle": {"color": _COR_GRADE}},
        },
        "series": [{"id": "teia", "type": "radar", "data": dados}],
    })
    return opt
