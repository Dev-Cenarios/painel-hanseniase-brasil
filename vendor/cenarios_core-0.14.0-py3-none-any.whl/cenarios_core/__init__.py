"""Núcleo comum dos painéis Cenários.

Cada painel instala uma versão **fixa** deste pacote — o wheel vai em
`vendor/` do painel e o lock aponta para ele —, então mexer aqui não muda
painel nenhum até ele subir a versão. Ver o README.
"""

__version__ = "0.14.0"
